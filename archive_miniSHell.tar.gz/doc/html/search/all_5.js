var searchData=
[
  ['isempty',['isEmpty',['../tree_8h.html#ae4ea4d4d609b15ac54146adeb64eb435',1,'tree.c']]],
  ['isemptystacktree',['isEmptyStackTree',['../stackTree_8h.html#a3e101266a4325d242ea73417931989f5',1,'stackTree.c']]]
];

var searchData=
[
  ['save_5fdot',['save_dot',['../tree_8h.html#a0bd2f6637ff829975a5c0349fc7ee22a',1,'tree.c']]],
  ['shellreader',['shellReader',['../shell_8h.html#aba0e7cbf36b01d94dd5d0b8a5e3e1c2b',1,'shell.c']]],
  ['sizetree',['sizeTree',['../tree_8h.html#ab471c13de30182fb7b9a0e0f2a0b7d6e',1,'tree.c']]]
];

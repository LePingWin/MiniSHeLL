var searchData=
[
  ['readerl',['readerL',['../shell_8h.html#a11b419f784bac628d7bbe2c8c2c5e21a',1,'shell.c']]],
  ['root',['root',['../tree_8h.html#a66fb9b676a07f944e35a2171cff66e4b',1,'tree.c']]]
];

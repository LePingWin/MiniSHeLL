var searchData=
[
  ['newnode',['newNode',['../stack_8h.html#ada4fdce0f2ef228b35f9eb95c11f9c9a',1,'stack.c']]],
  ['newnodestacktree',['newNodeStackTree',['../stackTree_8h.html#ac7860315aeb4e2ba097574b9e293146f',1,'stackTree.c']]]
];

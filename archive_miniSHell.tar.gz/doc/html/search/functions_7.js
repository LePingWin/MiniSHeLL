var searchData=
[
  ['shellreader',['shellReader',['../shell_8h.html#aba0e7cbf36b01d94dd5d0b8a5e3e1c2b',1,'shell.c']]],
  ['sizetree',['sizeTree',['../tree_8h.html#ab471c13de30182fb7b9a0e0f2a0b7d6e',1,'tree.c']]]
];

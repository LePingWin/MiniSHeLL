var indexSectionsWithContent =
{
  0: "bcemnpst",
  1: "nst",
  2: "bt",
  3: "cep",
  4: "b",
  5: "m",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Macros",
  6: "Pages"
};

